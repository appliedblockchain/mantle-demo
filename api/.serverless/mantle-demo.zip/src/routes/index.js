module.exports = [
  require('./notes'),
  require('./users')
]
