const APP_NAME = 'Starter app'
const API_PREFIX = '/api'

module.exports = {
  APP_NAME,
  API_PREFIX
}
