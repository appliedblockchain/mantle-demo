module.exports = {
  notFoundHandler: require('./notFound'),
  errorHandler: require('./errorHandler')
}
